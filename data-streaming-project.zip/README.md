# Data Streaming & Preprocessing Challenge

This repository contains solutions for the following tasks:

1. Data Preprocessing Challenge (Spark / PySpark)
2. Real-Time Data Streaming Challenge (Kafka producer + consumer)
3. Incremental Data Processing Challenge (CDC + incremental model updates)
4. In-Memory Data Processing Challenge (Spark caching/DataFrame/RDD)

---

## Contents

- `data_preprocessing/pyspark_preprocessing.py` — PySpark script demonstrating cleaning, type-casting, deduplication, normalization, and feature engineering. Input: CSV file (assumed schema in header). Output: Parquet file.

- `streaming/kafka_producer.py` — Example Kafka producer that generates JSON sensor-like messages and writes to a Kafka topic. (Designed to be copied & used with your Kafka cluster.)

- `streaming/kafka_consumer_streaming.py` — Kafka consumer that reads streaming messages, calculates rolling aggregates (rolling average), and performs incremental ML (SGDRegressor) using `partial_fit` to demonstrate real-time analytics.

- `cdc/kafka_connect_debezium_mysql.json` — Example Kafka Connect Debezium connector configuration for capturing MySQL changes (CDC).

- `cdc/cdc_processor.py` — Example consumer that receives CDC events from a Kafka topic, applies incremental updates (upsert) to a local model or database, and optionally retrains a model incrementally.

- `in_memory/spark_in_memory.py` — Example demonstrating in-memory DataFrame caching and a simple benchmark to show speed differences.

- `notebooks/Project_Report.md` — A short project report template with evaluation and submission checklist.

- `submission_checklist.md` — Checklist for the files and deliverables to include in the GitHub submission.

---

## Notes

- Files are annotated and designed to be portable. Replace placeholder configuration values (broker URLs, topic names, file paths) with values matching your environment.
- The code uses standard Python libraries and commonly-used packages (listed in `requirements.txt`).
- No shell commands are in this repo — the expectation is you will upload these files to GitHub using the platform UI (no CLI commands required).
