Submission checklist:

- [ ] README.md included and updated
- [ ] requirements.txt included
- [ ] data_preprocessing/pyspark_preprocessing.py included
- [ ] streaming/kafka_producer.py included
- [ ] streaming/kafka_consumer_streaming.py included
- [ ] cdc/kafka_connect_debezium_mysql.json included
- [ ] cdc/cdc_processor.py included
- [ ] in_memory/spark_in_memory.py included
- [ ] notebooks/Project_Report.md completed with test results
- [ ] License attached
