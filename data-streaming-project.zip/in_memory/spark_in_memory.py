"""Spark in-memory demo for caching speed improvements."""
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg

INPUT_PARQUET = "data/processed/cleaned_data.parquet"

spark = SparkSession.builder.appName("InMemoryDemo").getOrCreate()

df = spark.read.parquet(INPUT_PARQUET)

start = time.time()
res1 = df.groupBy('id').agg(avg('temperature').alias('avg_temp')).count()
end = time.time()
print(f"Query time without cache: {end - start:.2f} seconds")

df.cache()
start = time.time()
res2 = df.groupBy('id').agg(avg('temperature').alias('avg_temp')).count()
end = time.time()
print(f"Query time with cache: {end - start:.2f} seconds")

spark.stop()
