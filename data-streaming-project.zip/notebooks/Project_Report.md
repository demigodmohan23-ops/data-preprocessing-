# Project Report — Data Streaming & Preprocessing Challenge

## Summary
Brief description of the tasks completed and which files correspond to each task.

## Data Preprocessing
- File: `data_preprocessing/pyspark_preprocessing.py`
- Steps performed: missing-value handling, type enforcement, duplicate removal, normalization, feature engineering.

## Real-Time Streaming
- Files: `streaming/kafka_producer.py`, `streaming/kafka_consumer_streaming.py`
- Kafka topics used: `sensor_data` (example)
- Streaming analytics implemented: per-device rolling average, incremental regression using `SGDRegressor`.

## CDC / Incremental Processing
- Files: `cdc/kafka_connect_debezium_mysql.json`, `cdc/cdc_processor.py`
- Uses Debezium-like JSON envelope example to capture change events.

## In-memory Processing
- File: `in_memory/spark_in_memory.py`
- Demonstrates Spark DataFrame caching and benchmark prints.

## Evaluation
- Describe dataset size, throughput (messages/sec), and latency targets used during testing.
- Provide model performance metrics (e.g., incremental MSE, MAE) — you can append results here after testing.

## Submission checklist
See `submission_checklist.md` for a final list of deliverables to attach to your GitHub repo.
